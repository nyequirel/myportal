from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os, webbrowser, threading, time
root=Path(__file__).resolve().parent
os.chdir(root)
url='http://127.0.0.1:8765/'
threading.Thread(target=lambda:(time.sleep(.7),webbrowser.open(url)),daemon=True).start()
print('AI Background Remover Local Only')
print('Open:',url)
print('Press CTRL+C to stop.')
ThreadingHTTPServer(('127.0.0.1',8765),SimpleHTTPRequestHandler).serve_forever()
