$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$modelDir=Join-Path $root 'models'; $ortDir=Join-Path $root 'vendor\ort'; $vendor=Join-Path $root 'vendor'
New-Item -ItemType Directory -Force -Path $modelDir,$ortDir,$vendor|Out-Null
$model=Join-Path $modelDir 'isnet-general-use-q8.onnx'
$modelUrl='https://huggingface.co/SacredNoir/isnet-general-use-onnx/resolve/main/isnet-general-use-q8.onnx?download=true'
$expected='feed6f32a5e707ca7e939576b2d891b23fb9eb4114749657a5efc64e8651e43a'
$files=@{
 (Join-Path $ortDir 'ort.min.js')='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/ort.min.js';
 (Join-Path $ortDir 'ort-wasm-simd-threaded.mjs')='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/ort-wasm-simd-threaded.mjs';
 (Join-Path $ortDir 'ort-wasm-simd-threaded.wasm')='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/ort-wasm-simd-threaded.wasm';
 (Join-Path $vendor 'jszip.min.js')='https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js'
}
Write-Host 'Downloading local web runtime...'
foreach($kv in $files.GetEnumerator()){Invoke-WebRequest -Uri $kv.Value -OutFile $kv.Key}
Write-Host 'Downloading ISNet General Q8...'
Invoke-WebRequest -Uri $modelUrl -OutFile $model
$hash=(Get-FileHash $model -Algorithm SHA256).Hash.ToLower()
if($hash -ne $expected){Remove-Item $model -Force; throw "Model SHA-256 mismatch: $hash"}
Write-Host 'Local package ready. After this, it can run offline.'
