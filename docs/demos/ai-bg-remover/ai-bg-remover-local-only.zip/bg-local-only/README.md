# Local Only — AI Background Remover

เวอร์ชันนี้ไม่ใช้ GitHub Pages ตอนทำงาน และหลังเตรียมไฟล์ครั้งแรกสามารถทำงาน offline ได้.

## เตรียมครั้งแรก
1. รัน `PREPARE_LOCAL.bat` ขณะมีอินเทอร์เน็ต.
2. Script จะดาวน์โหลด ONNX Runtime Web, JSZip และ `isnet-general-use-q8.onnx` มาเก็บในโฟลเดอร์นี้.
3. หลังจากนั้นสามารถปิดอินเทอร์เน็ตได้.

## เปิดใช้งาน
ดับเบิลคลิก `START_LOCAL_SERVER.bat` แล้วเปิด `http://127.0.0.1:8765/`.

> ต้องเปิดผ่าน localhost เพราะ browser ไม่อนุญาตให้ `file://` fetch โมเดล/WASM โดยตรง.

Source ถูกรวมเป็นพื้นที่เดียว: เลือก Folder, เลือกหลายไฟล์ หรือ Drag & Drop ไฟล์ลงพื้นที่เดียวกันได้เลย.
