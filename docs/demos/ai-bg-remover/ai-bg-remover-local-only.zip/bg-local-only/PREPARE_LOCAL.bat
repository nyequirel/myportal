@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PREPARE_LOCAL.ps1"
pause
