@echo off
cd /d "%~dp0"
if not exist "models\isnet-general-use-q8.onnx" (
  echo Model not found. Run PREPARE_LOCAL.bat first.
  pause
  exit /b 1
)
if not exist "vendor\ort\ort.min.js" (
  echo Local runtime not found. Run PREPARE_LOCAL.bat first.
  pause
  exit /b 1
)
where py >nul 2>nul && (py -3 START_LOCAL_SERVER.py & exit /b)
where python >nul 2>nul && (python START_LOCAL_SERVER.py & exit /b)
echo Python was not found. Install Python or serve this folder with any local HTTP server.
pause
