$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host "================================================" -ForegroundColor DarkCyan
Write-Host " AI Background Remover - Local Only v5" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor DarkCyan
Write-Host "Root: $root" -ForegroundColor Gray

# Verify / prepare local model and runtime.
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'VERIFY_LOCAL.ps1')
if($LASTEXITCODE -ne 0){
  Write-Host "Required local files are missing. Running one-time preparation..." -ForegroundColor Yellow
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'PREPARE_LOCAL.ps1')
  if($LASTEXITCODE -ne 0){ throw 'Preparation failed. Run PREPARE_LOCAL.bat to retry or use the Local .onnx picker if you already have the model.' }
}

$model=Join-Path $root 'models\isnet-general-use-q8.onnx'
if(-not (Test-Path -LiteralPath $model -PathType Leaf)){ throw "Model missing after prepare: $model" }
Write-Host "Model OK: $model" -ForegroundColor Green

# Pick a free port. This avoids accidentally talking to an old server still using 8765.
function Test-PortFree([int]$Port){
  try{
    $l=[System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,$Port)
    $l.Start(); $l.Stop(); return $true
  }catch{return $false}
}
$port=$null
foreach($p in 8810..8840){ if(Test-PortFree $p){$port=$p;break} }
if($null -eq $port){ throw 'No free local port found in 8810-8840.' }
$prefix="http://127.0.0.1:$port/"
Write-Host "Serving THIS folder on: $prefix" -ForegroundColor Green
Write-Host "v5 uses ports 8810-8840 and serves the verified JSEP runtime from this folder." -ForegroundColor DarkGray

$listener=New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)
$listener.Start()

$mime=@{
 '.html'='text/html; charset=utf-8'; '.htm'='text/html; charset=utf-8';
 '.js'='text/javascript; charset=utf-8'; '.mjs'='text/javascript; charset=utf-8';
 '.css'='text/css; charset=utf-8'; '.json'='application/json';
 '.wasm'='application/wasm'; '.onnx'='application/octet-stream';
 '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.webp'='image/webp'; '.svg'='image/svg+xml'
}

Start-Process $prefix
Write-Host "Browser opened. Press CTRL+C to stop this server." -ForegroundColor Cyan
try{
  while($listener.IsListening){
    $ctx=$listener.GetContext()
    try{
      $path=$ctx.Request.Url.AbsolutePath
      if($path -eq '/__health'){
        $modelOk=(Test-Path -LiteralPath $model -PathType Leaf)
        $modelSize=if($modelOk){(Get-Item -LiteralPath $model).Length}else{0}
        $modelHash=if($modelOk){(Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash.ToLower()}else{''}
        $payload=@{ok=$true;version='local-v5';root=$root;model=$modelOk;modelSize=$modelSize;modelHash=$modelHash;port=$port}|ConvertTo-Json -Compress
        $bytes=[Text.Encoding]::UTF8.GetBytes($payload)
        $ctx.Response.StatusCode=200;$ctx.Response.ContentType='application/json; charset=utf-8'
        $ctx.Response.Headers['Cache-Control']='no-store'
      }elseif($path -eq '/__model'){
        if(-not (Test-Path -LiteralPath $model -PathType Leaf)){
          $ctx.Response.StatusCode=404
          $bytes=[Text.Encoding]::UTF8.GetBytes('Model missing from verified launcher path')
          $ctx.Response.ContentType='text/plain; charset=utf-8'
        }else{
          $ctx.Response.StatusCode=200
          $ctx.Response.ContentType='application/octet-stream'
          $ctx.Response.Headers['Cache-Control']='no-store'
          $ctx.Response.Headers['X-Local-Model']='isnet-general-use-q8.onnx'
          $bytes=[IO.File]::ReadAllBytes($model)
        }
      }else{
        $rel=[Uri]::UnescapeDataString($path.TrimStart('/'))
        if([string]::IsNullOrWhiteSpace($rel)){$rel='index.html'}
        $candidate=[IO.Path]::GetFullPath((Join-Path $root $rel))
        $rootFull=[IO.Path]::GetFullPath($root)
        if(-not $candidate.StartsWith($rootFull,[StringComparison]::OrdinalIgnoreCase)){throw 'Forbidden'}
        if(-not (Test-Path -LiteralPath $candidate -PathType Leaf)){
          $ctx.Response.StatusCode=404
          $bytes=[Text.Encoding]::UTF8.GetBytes("404 Not Found`nRoot: $root`nRequested: $candidate")
          $ctx.Response.ContentType='text/plain; charset=utf-8'
        }else{
          $ctx.Response.StatusCode=200
          $ext=[IO.Path]::GetExtension($candidate).ToLowerInvariant()
          $ctx.Response.ContentType=if($mime.ContainsKey($ext)){$mime[$ext]}else{'application/octet-stream'}
          $ctx.Response.Headers['Cache-Control']='no-store'
          $bytes=[IO.File]::ReadAllBytes($candidate)
        }
      }
      $ctx.Response.Headers['Cross-Origin-Opener-Policy']='same-origin'
      $ctx.Response.Headers['Cross-Origin-Embedder-Policy']='require-corp'
      $ctx.Response.Headers['X-Content-Type-Options']='nosniff'
      $ctx.Response.ContentLength64=$bytes.Length
      $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    }catch{
      $ctx.Response.StatusCode=500
      $bytes=[Text.Encoding]::UTF8.GetBytes($_.Exception.Message)
      $ctx.Response.Headers['Cross-Origin-Opener-Policy']='same-origin'
      $ctx.Response.Headers['Cross-Origin-Embedder-Policy']='require-corp'
      $ctx.Response.Headers['X-Content-Type-Options']='nosniff'
      $ctx.Response.ContentLength64=$bytes.Length
      $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length)
    }finally{$ctx.Response.OutputStream.Close()}
  }
}finally{$listener.Stop();$listener.Close()}
