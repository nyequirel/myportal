# AI Background Remover — Local Only v5

รุ่นนี้แก้ปัญหา `no available backend found` ของ ONNX Runtime Web โดยตรง

## สิ่งที่แก้ใน v5
- ใช้ `onnxruntime-web@1.30.0` พร้อม JSEP runtime ที่ตรงชุด:
  - `vendor/ort/ort.min.js`
  - `vendor/ort/ort-wasm-simd-threaded.jsep.mjs`
  - `vendor/ort/ort-wasm-simd-threaded.jsep.wasm`
- ตั้ง `ort.env.wasm.wasmPaths` เป็น URL แบบ absolute เพื่อไม่ให้เกิด `vendor/ort/vendor/ort/...`
- `VERIFY_LOCAL.ps1` ตรวจ JSEP runtime จริงก่อนเปิดเว็บ
- `PREPARE_LOCAL.ps1` จะดาวน์โหลด JSEP runtime ใหม่ และลบ runtime non-JSEP รุ่นเก่าที่อาจทำให้สับสน
- Local server ส่ง MIME `.mjs = text/javascript` และ `.wasm = application/wasm` พร้อม isolation headers
- ใช้พอร์ต 8810–8840 เพื่อเลี่ยง server รุ่นเก่า

## วิธีใช้
1. แตก ZIP ไปโฟลเดอร์ใหม่
2. ปิดหน้าต่าง Local server รุ่นเก่าทั้งหมด
3. ดับเบิลคลิก `START_LOCAL_TOOL.bat`
4. ถ้าไฟล์ model/runtime ยังไม่ครบ ตัว launcher จะดาวน์โหลดให้อัตโนมัติครั้งแรก
5. Browser จะเปิด URL ประมาณ `http://127.0.0.1:8810/`

## ตรวจสอบ
เปิด `http://127.0.0.1:<port>/__health`
ควรเห็น `version: local-v5` และ `model: true`

หากยังมี runtime error ให้ลบโฟลเดอร์ `vendor/ort/` แล้วรัน `START_LOCAL_TOOL.bat` ใหม่ เพื่อให้ Prepare ดาวน์โหลดชุด JSEP ใหม่ทั้งหมด
