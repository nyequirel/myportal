$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$model=Join-Path $root 'models\isnet-general-use-q8.onnx'
$ortJs=Join-Path $root 'vendor\ort\ort.min.js'
$ortMjs=Join-Path $root 'vendor\ort\ort-wasm-simd-threaded.jsep.mjs'
$ortWasm=Join-Path $root 'vendor\ort\ort-wasm-simd-threaded.jsep.wasm'
$jszip=Join-Path $root 'vendor\jszip.min.js'
$expectedHash='feed6f32a5e707ca7e939576b2d891b23fb9eb4114749657a5efc64e8651e43a'
$expectedSize=44436071

$problems=@()
if(-not (Test-Path -LiteralPath $model -PathType Leaf)){$problems += "Missing model: $model"}
else {
  $len=(Get-Item -LiteralPath $model).Length
  if($len -lt 44000000){$problems += "Model file is too small: $len bytes"}
  else {
    $hash=(Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash.ToLower()
    if($hash -ne $expectedHash){$problems += "Model SHA-256 mismatch: $hash"}
  }
}
$runtimeChecks=@(
  @{Path=$ortJs;Min=100000},
  @{Path=$ortMjs;Min=1000},
  @{Path=$ortWasm;Min=1000000},
  @{Path=$jszip;Min=50000}
)
foreach($c in $runtimeChecks){
  if(-not (Test-Path -LiteralPath $c.Path -PathType Leaf)){ $problems += "Missing runtime: $($c.Path)" }
  elseif((Get-Item -LiteralPath $c.Path).Length -lt [long]$c.Min){ $problems += "Runtime file is too small: $($c.Path)" }
}
if($problems.Count -gt 0){
  foreach($p in $problems){ Write-Host "[MISSING] $p" -ForegroundColor Yellow }
  exit 1
}
Write-Host "[OK] Local model and JSEP runtimes are ready." -ForegroundColor Green
Write-Host "[OK] Model: isnet-general-use-q8.onnx ($expectedSize bytes expected)" -ForegroundColor Green
exit 0
