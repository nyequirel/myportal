@echo off
setlocal
cd /d "%~dp0"
title AI Background Remover - Local Only
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0START_LOCAL_TOOL.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo Local Tool stopped with error code %RC%.
  pause
)
exit /b %RC%
