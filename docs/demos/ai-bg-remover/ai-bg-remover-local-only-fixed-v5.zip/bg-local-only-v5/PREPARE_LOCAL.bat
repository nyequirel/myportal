@echo off
setlocal
cd /d "%~dp0"
title AI Background Remover - Prepare Local
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PREPARE_LOCAL.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo PREPARE FAILED with code %RC%.
  echo Check your Internet/proxy/firewall, then run this file again.
) else (
  echo PREPARE COMPLETED SUCCESSFULLY.
)
pause
exit /b %RC%
