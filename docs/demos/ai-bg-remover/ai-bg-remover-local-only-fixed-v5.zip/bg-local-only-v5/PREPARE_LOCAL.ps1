$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$modelDir=Join-Path $root 'models'
$ortDir=Join-Path $root 'vendor\ort'
$vendor=Join-Path $root 'vendor'
New-Item -ItemType Directory -Force -Path $modelDir,$ortDir,$vendor|Out-Null

$model=Join-Path $modelDir 'isnet-general-use-q8.onnx'
$modelUrl='https://huggingface.co/SacredNoir/isnet-general-use-onnx/resolve/main/isnet-general-use-q8.onnx?download=true'
$expectedHash='feed6f32a5e707ca7e939576b2d891b23fb9eb4114749657a5efc64e8651e43a'
$expectedSize=44436071

$downloads=@(
  @{Path=(Join-Path $ortDir 'ort.min.js'); Url='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/ort.min.js'; Min=100000},
  @{Path=(Join-Path $ortDir 'ort-wasm-simd-threaded.jsep.mjs'); Url='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/ort-wasm-simd-threaded.jsep.mjs'; Min=1000},
  @{Path=(Join-Path $ortDir 'ort-wasm-simd-threaded.jsep.wasm'); Url='https://cdn.jsdelivr.net/npm/onnxruntime-web@1.30.0/dist/ort-wasm-simd-threaded.jsep.wasm'; Min=1000000},
  @{Path=(Join-Path $vendor 'jszip.min.js'); Url='https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js'; Min=50000}
)

function Download-File([string]$Url,[string]$Destination,[long]$MinBytes=1){
  $tmp="$Destination.download"
  Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
  Write-Host "Downloading: $Url" -ForegroundColor Cyan
  $curl=Get-Command curl.exe -ErrorAction SilentlyContinue
  if($curl){
    & $curl.Source -L --fail --retry 3 --retry-delay 2 --connect-timeout 30 --output $tmp $Url
    if($LASTEXITCODE -ne 0){ throw "curl failed with exit code $LASTEXITCODE" }
  } else {
    Invoke-WebRequest -Uri $Url -OutFile $tmp -UseBasicParsing -MaximumRedirection 10
  }
  if(-not (Test-Path -LiteralPath $tmp -PathType Leaf)){ throw "Download did not create file: $tmp" }
  $len=(Get-Item -LiteralPath $tmp).Length
  if($len -lt $MinBytes){ throw "Downloaded file is too small: $len bytes ($Destination)" }
  Move-Item -LiteralPath $tmp -Destination $Destination -Force
}


# Remove old non-JSEP runtime files from earlier versions to avoid confusion.
Remove-Item -LiteralPath (Join-Path $ortDir 'ort-wasm-simd-threaded.mjs') -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $ortDir 'ort-wasm-simd-threaded.wasm') -Force -ErrorAction SilentlyContinue

Write-Host "================================================" -ForegroundColor DarkCyan
Write-Host " AI Background Remover - Prepare Local Offline" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor DarkCyan
Write-Host "This step needs Internet only once." -ForegroundColor Gray
Write-Host ""

foreach($d in $downloads){
  $need=$true
  if(Test-Path -LiteralPath $d.Path -PathType Leaf){
    if((Get-Item -LiteralPath $d.Path).Length -ge [long]$d.Min){$need=$false}
  }
  if($need){ Download-File $d.Url $d.Path ([long]$d.Min) }
  else { Write-Host "Already present: $($d.Path)" -ForegroundColor DarkGray }
}

$validModel=$false
if(Test-Path -LiteralPath $model -PathType Leaf){
  $len=(Get-Item -LiteralPath $model).Length
  if($len -ge 44000000){
    $hash=(Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash.ToLower()
    if($hash -eq $expectedHash){$validModel=$true}
  }
}
if(-not $validModel){
  Remove-Item -LiteralPath $model -Force -ErrorAction SilentlyContinue
  Download-File $modelUrl $model 44000000
}

$actualSize=(Get-Item -LiteralPath $model).Length
$actualHash=(Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash.ToLower()
if($actualSize -ne $expectedSize){
  Write-Host "WARNING: model size is $actualSize bytes; expected $expectedSize. Hash verification will decide validity." -ForegroundColor Yellow
}
if($actualHash -ne $expectedHash){
  Remove-Item -LiteralPath $model -Force
  throw "Model SHA-256 mismatch: $actualHash"
}

& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'VERIFY_LOCAL.ps1')
if($LASTEXITCODE -ne 0){ throw "Verification failed after download." }

Write-Host ""
Write-Host "READY. Local AI files are complete." -ForegroundColor Green
Write-Host "Model path: $model" -ForegroundColor Green
Write-Host "You can now run offline." -ForegroundColor Green
